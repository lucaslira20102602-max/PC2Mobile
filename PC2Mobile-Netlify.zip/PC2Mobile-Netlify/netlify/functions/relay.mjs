import { getStore } from "@netlify/blobs";

const store = getStore("pc2mobile-sessions");
const MAX_AGE_MS = 30 * 60 * 1000;
const MAX_EVENTS = 250;

function response(statusCode, body) {
  return {
    statusCode,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "access-control-allow-origin": "*",
      "access-control-allow-headers": "content-type",
      "access-control-allow-methods": "POST, OPTIONS"
    },
    body: JSON.stringify(body)
  };
}

function validCode(value) {
  return typeof value === "string" && /^\d{6}$/.test(value);
}

async function readSession(code) {
  const session = await store.get(`session:${code}`, { type: "json" });
  if (!session) return null;
  if (Date.now() - session.createdAt > MAX_AGE_MS) {
    await store.delete(`session:${code}`);
    return null;
  }
  return session;
}

async function writeSession(session) {
  session.updatedAt = Date.now();
  await store.setJSON(`session:${session.code}`, session);
}

export const handler = async (req) => {
  if (req.httpMethod === "OPTIONS") return response(204, {});
  if (req.httpMethod !== "POST") return response(405, { error: "Use POST." });

  let data;
  try { data = JSON.parse(req.body || "{}"); }
  catch { return response(400, { error: "JSON inválido." }); }

  const action = data.action;

  if (action === "create") {
    for (let tries = 0; tries < 8; tries++) {
      const code = String(Math.floor(100000 + Math.random() * 900000));
      if (await store.get(`session:${code}`, { type: "json" })) continue;
      const now = Date.now();
      const session = { code, createdAt: now, updatedAt: now, pcSeen: now, phoneSeen: 0, nextSeq: 1, events: [] };
      await writeSession(session);
      return response(200, { ok: true, code, expiresInMinutes: 30 });
    }
    return response(503, { error: "Não foi possível gerar o código. Tente novamente." });
  }

  if (!validCode(data.code)) return response(400, { error: "Código de 6 dígitos inválido." });
  const session = await readSession(data.code);
  if (!session) return response(404, { error: "Sessão não encontrada ou expirada. Gere outro código no notebook." });

  if (action === "join") {
    session.phoneSeen = Date.now();
    await writeSession(session);
    return response(200, { ok: true, code: session.code, afterSeq: session.nextSeq - 1 });
  }

  if (action === "status") {
    session.pcSeen = Date.now();
    await writeSession(session);
    return response(200, { ok: true, phoneOnline: Date.now() - session.phoneSeen < 12000, expiresInMinutes: Math.max(0, Math.ceil((MAX_AGE_MS - (Date.now() - session.createdAt)) / 60000)) });
  }

  if (action === "send") {
    if (!data.event || typeof data.event !== "object") return response(400, { error: "Evento inválido." });
    const event = data.event;
    const allowedTypes = new Set(["key", "mouseMove", "mouseButton"]);
    if (!allowedTypes.has(event.type)) return response(400, { error: "Tipo de evento não permitido." });
    session.events.push({ seq: session.nextSeq++, at: Date.now(), event });
    if (session.events.length > MAX_EVENTS) session.events = session.events.slice(-MAX_EVENTS);
    session.pcSeen = Date.now();
    await writeSession(session);
    return response(200, { ok: true, seq: session.nextSeq - 1 });
  }

  if (action === "poll") {
    const afterSeq = Number.isFinite(Number(data.afterSeq)) ? Number(data.afterSeq) : 0;
    session.phoneSeen = Date.now();
    const events = session.events.filter(item => item.seq > afterSeq);
    await writeSession(session);
    return response(200, { ok: true, events, latestSeq: session.nextSeq - 1 });
  }

  return response(400, { error: "Ação desconhecida." });
};

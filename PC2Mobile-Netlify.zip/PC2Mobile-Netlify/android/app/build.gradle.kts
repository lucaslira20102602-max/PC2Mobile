plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.pc2mobile.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.pc2mobile.app"
        minSdk = 26
        targetSdk = 28
        versionCode = 4
        versionName = "0.4.0"
    }
}
dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}

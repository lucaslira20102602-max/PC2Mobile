package com.pc2mobile.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import org.json.JSONArray
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val client = OkHttpClient.Builder().callTimeout(8, TimeUnit.SECONDS).build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private lateinit var serverInput: EditText
    private lateinit var codeInput: EditText
    private lateinit var status: TextView
    private lateinit var events: TextView
    @Volatile private var running = false
    private var worker: Thread? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(34, 46, 34, 28)
            setBackgroundColor(Color.rgb(10, 15, 23))
        }
        fun label(text: String, size: Float = 15f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(Color.rgb(235, 242, 250)); setPadding(0, 10, 0, 8)
        }
        root.addView(label("PC2Mobile", 29f))
        root.addView(label("Receptor pela internet • Minecraft Bedrock", 15f))
        root.addView(label("Endereço do site Netlify"))
        serverInput = EditText(this).apply {
            setSingleLine(true); setText("https://SEU-SITE.netlify.app")
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); hint = "https://seu-site.netlify.app"
        }
        root.addView(serverInput, LinearLayout.LayoutParams(-1, -2))
        root.addView(label("Código de pareamento (6 dígitos)"))
        codeInput = EditText(this).apply {
            setSingleLine(true); inputType = 2
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); hint = "Código mostrado no notebook"
        }
        root.addView(codeInput, LinearLayout.LayoutParams(-1, -2))
        root.addView(Button(this).apply { text = "Conectar ao notebook"; setOnClickListener { connectToRelay() } }, LinearLayout.LayoutParams(-1, -2))
        root.addView(Button(this).apply { text = "Desconectar"; setOnClickListener { stopRelay("Desconectado") } }, LinearLayout.LayoutParams(-1, -2))
        status = label("Desconectado", 16f); root.addView(status)
        root.addView(label("Últimos eventos recebidos"))
        events = label("Nenhum evento recebido.", 12f)
        root.addView(ScrollView(this).apply { addView(events) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(label("Aviso: este protótipo recebe e mostra eventos. Ainda não injeta teclado/mouse no Minecraft.", 11f))
        setContentView(root)
    }

    private fun post(base: String, payload: JSONObject): JSONObject {
        val request = Request.Builder().url(base.trimEnd('/') + "/.netlify/functions/relay")
            .post(payload.toString().toRequestBody(jsonType)).build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            val result = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
            if (!response.isSuccessful) throw IOException(result.optString("error", "HTTP ${response.code}"))
            return result
        }
    }

    private fun connectToRelay() {
        stopRelay(null)
        val base = serverInput.text.toString().trim().removeSuffix("/")
        val code = codeInput.text.toString().filter { it.isDigit() }.take(6)
        if (code.length != 6 || !base.startsWith("https://")) {
            status.text = "Informe o endereço HTTPS do Netlify e o código de 6 dígitos."; return
        }
        status.text = "Conectando…"
        running = true
        worker = Thread {
            try {
                val joined = post(base, JSONObject().put("action", "join").put("code", code))
                var afterSeq = joined.optLong("afterSeq", 0L)
                runOnUiThread { status.text = "Pareado. Aguardando eventos do notebook…" }
                while (running) {
                    val result = post(base, JSONObject().put("action", "poll").put("code", code).put("afterSeq", afterSeq))
                    val items: JSONArray = result.optJSONArray("events") ?: JSONArray()
                    for (i in 0 until items.length()) {
                        val item = items.optJSONObject(i) ?: continue
                        afterSeq = maxOf(afterSeq, item.optLong("seq", afterSeq))
                        val ev = item.optJSONObject("event") ?: continue
                        val line = "${ev.optString("type")} · ${ev.optString("key", ev.optString("button", ""))} · ${ev.optString("action", "")}\n"
                        runOnUiThread { events.text = (line + events.text.toString()).take(2500) }
                    }
                    Thread.sleep(850)
                }
            } catch (e: Exception) {
                if (running) runOnUiThread { status.text = "Falha: ${e.message ?: "não foi possível conectar"}" }
                running = false
            }
        }.apply { name = "PC2Mobile-Polling"; start() }
    }

    private fun stopRelay(message: String?) {
        running = false
        worker?.interrupt()
        worker = null
        if (message != null && ::status.isInitialized) status.text = message
    }

    override fun onDestroy() {
        stopRelay(null)
        client.dispatcher.executorService.shutdown()
        super.onDestroy()
    }
}

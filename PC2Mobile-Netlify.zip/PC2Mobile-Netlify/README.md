# PC2Mobile Netlify Edition (protótipo 0.4)

Esta versão remove o servidor Node/WebSocket separado e usa uma Netlify Function + Netlify Blobs para transmitir eventos por requisições HTTPS periódicas. O notebook e o Android podem estar em redes diferentes.

## Publicação

1. Envie **todo o conteúdo desta pasta** para um repositório GitHub.
2. No Netlify, escolha **Add new project → Import an existing project** e conecte o repositório.
3. O arquivo `netlify.toml` configura automaticamente `public` como pasta publicada e `netlify/functions` como funções.
4. Publique o site. O projeto usa `@netlify/blobs`, incluído em `package.json`; o Netlify fornece o contexto da loja em produção.
5. Abra o endereço publicado e clique em **Gerar código de conexão**.
6. No Android, informe o endereço completo do site Netlify e o código exibido no notebook.
7. Clique em **Ativar controles** no notebook para enviar eventos de teclado/mouse enquanto a página estiver em foco.

## Android

A pasta `android` contém o código-fonte de um aplicativo Android para abrir no Android Studio. Configure/compile o APK no Android Studio; este ZIP não inclui um APK já compilado.

## Limitações importantes

- Isto é um protótipo de comunicação, não um controle de jogo pronto. O APK recebe e exibe eventos, mas **não injeta** teclado/mouse no Minecraft Bedrock.
- O navegador só captura eventos enquanto a página está aberta e focada; não funciona como um driver global de teclado/mouse.
- A função usa um código temporário de 6 dígitos e armazenamento compartilhado. Antes de uso público, adicione autenticação, proteção contra tentativas de adivinhação e controles de abuso. Não use para enviar dados sensíveis.
- A conexão usa polling HTTPS, portanto pode ter latência e não equivale a um canal WebSocket contínuo.
- As sessões expiram após 30 minutos. A persistência de Netlify Blobs depende de o projeto estar corretamente publicado no Netlify.

## Desenvolvimento local

Para testar localmente, instale Node.js e a CLI do Netlify e use `netlify dev`; a função depende do contexto de Netlify Blobs. Não é necessário executar comandos no uso normal após publicar.

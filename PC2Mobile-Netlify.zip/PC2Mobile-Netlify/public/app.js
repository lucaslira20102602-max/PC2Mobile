const $ = id => document.getElementById(id);
const endpoint = "/.netlify/functions/relay";
let connected = false, capturing = false, count = 0, code = "", statusTimer = null;
const held = new Set();
const api = async payload => {
  const r = await fetch(endpoint, { method:"POST", headers:{"content-type":"application/json"}, body:JSON.stringify(payload) });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `Erro HTTP ${r.status}`);
  return data;
};
function setStatus(text, ok=false) { $("statusText").textContent=text; $("statusDot").classList.toggle("green",ok); }
function logEvent(name, detail="") {
  const box=$("eventLog"), empty=box.querySelector(".empty-log"); if(empty) empty.remove();
  const row=document.createElement("div"); row.className="log-line";
  const time=document.createElement("time"); time.textContent=new Date().toLocaleTimeString("pt-BR",{hour12:false});
  const body=document.createElement("span"), b=document.createElement("b"); b.textContent=name; body.append(b,document.createTextNode(detail?" · "+detail:"")); row.append(time,body); box.prepend(row);
  while(box.children.length>50) box.lastElementChild.remove();
}
async function sendInput(event) {
  if(!connected || !code) return;
  try { await api({action:"send",code,event}); count++; $("sentCount").textContent=`${count} eventos enviados`; $("keyFeed").textContent=event.type==="key"?`${event.key} ${event.action}`:event.type; }
  catch(err){ $("pairStatus").textContent=err.message; }
}
async function connect() {
  if(connected) { $("pairStatus").textContent="Já existe uma sessão ativa."; return; }
  $("connectBtn").disabled=true; $("pairStatus").textContent="Gerando sessão segura…"; setStatus("Criando sessão");
  try {
    const result=await api({action:"create"}); code=result.code; connected=true;
    $("pairCode").value=code; $("captureBtn").disabled=false; $("pairStatus").textContent="Código pronto. Digite-o no aplicativo Android.";
    setStatus("Aguardando celular",true); logEvent("Sessão criada",`código ${code}`); statusTimer=setInterval(checkStatus,2500);
  } catch(err) { $("pairStatus").textContent=`Não foi possível criar sessão: ${err.message}. Confirme se o site foi publicado pelo GitHub com as Netlify Functions.`; setStatus("Erro de conexão"); }
  finally { $("connectBtn").disabled=false; }
}
async function checkStatus(){ if(!connected||!code)return; try { const s=await api({action:"status",code}); const online=!!s.phoneOnline; $("phoneState").textContent=online?"Conectado pela internet":"Aguardando celular"; $("phonePill").textContent=online?"CONECTADO":"OFFLINE"; $("phonePill").classList.toggle("online",online); if(online){$("pairStatus").textContent="Celular pareado. Você já pode testar o envio de eventos.";setStatus("Celular conectado",true);}else{setStatus("Aguardando celular",true);} }catch(err){$("pairStatus").textContent=err.message;} }
function disconnect(){stopCapture(); if(statusTimer)clearInterval(statusTimer); statusTimer=null; connected=false; code=""; $("pairCode").value="------"; $("captureBtn").disabled=true; $("phoneState").textContent="Ainda não conectado"; $("phonePill").textContent="OFFLINE"; $("phonePill").classList.remove("online"); $("pairStatus").textContent="Sessão encerrada. Gere outro código para reconectar."; setStatus("Desconectado"); }
function startCapture(){if(!connected){$("pairStatus").textContent="Gere um código primeiro.";return;} capturing=true; $("captureBtn").textContent="Desativar controles"; $("captureBtn").style.background="#f2c879"; $("keyFeed").textContent="Captura ativa"; document.body.tabIndex=0; document.body.focus(); logEvent("Captura ativada","mantenha a página em foco");}
function stopCapture(){if(!capturing)return; for(const key of held) void sendInput({type:"key",key,action:"up"}); held.clear(); capturing=false; $("captureBtn").textContent="Ativar controles"; $("captureBtn").style.background=""; $("keyFeed").textContent="Captura desativada";}
$("connectBtn").addEventListener("click",connect); $("disconnectBtn").addEventListener("click",disconnect); $("captureBtn").addEventListener("click",()=>capturing?stopCapture():startCapture());
$("copyCode").addEventListener("click",async()=>{if(!code)return;try{await navigator.clipboard.writeText(code);$("pairStatus").textContent="Código copiado.";}catch{$("pairStatus").textContent=`Código: ${code}`;}});
$("clearLog").addEventListener("click",()=>$("eventLog").innerHTML='<div class="empty-log"><span>⌁</span><b>Registro limpo</b><small>Os próximos eventos aparecerão aqui.</small></div>');
window.addEventListener("keydown",e=>{if(!capturing||e.repeat)return;if(["INPUT","TEXTAREA"].includes(document.activeElement?.tagName))return;if(e.key==="Escape"){stopCapture();return;}if([" ","ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Tab"].includes(e.key))e.preventDefault();const key=e.key.length===1?e.key.toUpperCase():e.key;held.add(key);void sendInput({type:"key",key,action:"down"});});
window.addEventListener("keyup",e=>{if(!capturing)return;const key=e.key.length===1?e.key.toUpperCase():e.key;held.delete(key);void sendInput({type:"key",key,action:"up"});});
window.addEventListener("mousemove",e=>{if(capturing)void sendInput({type:"mouseMove",x:e.clientX,y:e.clientY,dx:e.movementX,dy:e.movementY});});
window.addEventListener("mousedown",e=>{if(capturing)void sendInput({type:"mouseButton",button:e.button,action:"down"});});
window.addEventListener("mouseup",e=>{if(capturing)void sendInput({type:"mouseButton",button:e.button,action:"up"});});
window.addEventListener("blur",()=>{if(capturing)stopCapture();});
